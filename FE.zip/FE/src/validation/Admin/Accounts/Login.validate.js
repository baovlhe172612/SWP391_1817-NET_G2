export const validate = (login) => {
    
}
