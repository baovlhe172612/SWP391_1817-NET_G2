export const messageAdminActions = (payload) => ({
    type: "GET_ALL_MESSAGE",
    payload: payload
})