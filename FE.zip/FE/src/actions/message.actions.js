export const messageActions = (payload) => ({
    type: "GET_ALL_MESSAGE",
    payload: payload
})