export const accountActions = (payload) => {
    return {
        type: "NEW_ACCOUNT",
        payload: payload,
    }
}