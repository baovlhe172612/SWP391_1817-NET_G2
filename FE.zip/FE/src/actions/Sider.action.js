export const siderActions = (payload) => {
    return {
        type: "NEW_SELECT_SIDER",
        payload: payload,
    }
}