export const connectActions = (payload) => ({
    type: "CONNECTION",
    payload: payload
});