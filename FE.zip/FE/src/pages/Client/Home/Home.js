import OurProducts from "../../../components/Client/Product/OurProducts";
import NewProduct from "../../../components/Client/Product/NewProduct";
import QRCodeComponent from "../QRScanner/QRScanner";
function Home() {
  return (
    <>
      <OurProducts />
      <NewProduct />
    </>
  );
}

export default Home;
